import { motion } from 'framer-motion';
import './styles.css';
import { AnimatedButton, Example1, Example2, Examples } from './Examples';
import React, { HTMLAttributes } from "react";
import { styled } from '@stitches/react';

const style = {};
export default function App() {
  const [counter, increase] = React.useReducer((counter) => counter + 1, 0);
  return (
    <div className="App">
      <h2>rotate and scale \w variants</h2>
      <AnimatedButton />
      <RefreshButton onClick={increase}>refresh!</RefreshButton>
      <Examples _={counter} />
    </div>
  );
}

const RefreshButton = styled("button", {
  position: "fixed",
  top: "30px",
  right: "20px",
  background: "linear-gradient(90deg,#ffa0ae 0%,#ffffff 75%)",
  borderRadius: "10px",
  width: "200px",
  height: "100px",
  fontSize: "2rem"
});